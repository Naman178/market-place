<!-- Footer Start -->
<div class="flex-grow-1"></div>
<div class="app-footer">
    <div class="row">
        <p><strong>ERP 2023 All rights reserved</strong></p>
    </div>
</div>
<!-- fotter end -->
