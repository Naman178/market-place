$(document).ready(function(){
    $('#picker2, #picker3').pickadate();
});